﻿function Product() {

}

function Instructor(firstName, lastName, description, imageUrl) {
    self.FirstName= firstName;
    self.LastName = lastName;
    self.Description = description;
    self.ImageUrl = imageUrl;
}


// "main" employee viewmodel
function InstructorViewModel() {
    //self.instructors = ko.utils.parseJson(data);
    self.selectedInstructorId = ko.observable('');
   
    // on model bind, fire service and load observable array
    $.ajax({
        url: '../api/Instructors/Get',
        type: 'GET',
        async: true,
        dataType: "json",
        contentType: 'application/json; charset=utf-8',
        success: function (result) {
            self.instructors(result);
        },
        error: function (err) {
            alert('error!');
        }
    });
}

// additional functions

// could use much more logic testing here but for illustrative purposes this should suffice
// also, alert() is poor design choice for presenting info to user. if more time, would use bootstrap modals
function LoadMsg(data, status, xhr)  {
  alert(data.msg);
}

